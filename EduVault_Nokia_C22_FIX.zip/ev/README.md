# EduVault Android Build
Phone-friendly Flutter source package for building the EduVault APK with GitHub Actions.
This first APK is a working offline/demo app shell. Real Supabase authentication, PDF storage and production AI are separate configuration steps.
