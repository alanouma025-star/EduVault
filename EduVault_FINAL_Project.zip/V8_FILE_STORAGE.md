# EduVault V8 — PDF Upload & Storage

## Implemented
Contributor selects a PDF → EduVault uploads it to private Supabase Storage → metadata is linked to the material → material remains `pending_review`.

PDF rules in the demo:
- PDF only
- Maximum 25 MB
- Contributor must confirm they have distribution rights

## Security
Files are stored in a private bucket. Students should receive short-lived signed URLs only for approved/published material.

## Production requirement
The upload UI should also verify that the contributor has an approved contributor role. Database and Storage policies enforce this; the UI alone is not trusted.
