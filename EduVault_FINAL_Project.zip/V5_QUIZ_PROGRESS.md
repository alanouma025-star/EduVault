# EduVault V5 — Quiz & Progress

## Included
- Published quiz retrieval
- Topic/subject quiz filtering
- Question retrieval
- Score calculation
- Quiz-attempt saving
- Topic progress updates
- Student progress retrieval
- Quiz-history retrieval
- Working browser quiz demo

## Student flow
Choose Quiz → Answer → Submit → Immediate Score → Save Attempt → Update Topic Progress

## Next production layer
Add:
- multiple quizzes per topic
- explanations after each answer
- timed quizzes
- randomized question order
- flashcards
- achievements/streaks
- progress dashboard charts
- admin quiz creation/editor
