# EduVault V6 — Student Dashboard & Achievements

Dashboard metrics:
- overall topic progress
- average quiz score
- quizzes completed
- topics studied
- saved materials
- downloads

Starter achievements:
- First Quiz
- 10 Topics Studied
- 90% Quiz Score
- 10 Downloads

The production Android dashboard can turn these into cards, progress bars, subject breakdowns and study-history charts.
