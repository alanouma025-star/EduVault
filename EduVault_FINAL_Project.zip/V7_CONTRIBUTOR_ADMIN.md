# EduVault V7 — Contributor & Admin

Workflow:

Contributor creates submission
→ pending_review
→ Admin checks content, category and rights
→ approved / rejected / removed
→ approved content can be published for students

The system records:
- contributor
- title/description
- subject/topic
- material type
- author
- rights confirmation
- status
- timestamps

Important: rights confirmation is a declaration, not legal proof. EduVault should retain appropriate permission/licence records for third-party materials.
