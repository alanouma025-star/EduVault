# EduVault Final Package

This is the consolidated source package containing the completed EduVault flows built so far: authentication, academic profile, material library, PDF upload/storage, contributor workflow, admin review, student reader/download, AI Tutor scaffold, quizzes, progress, dashboard and achievements.

Private credentials remain placeholders. Do not put secrets in chat.

IMPORTANT: This environment does not have Flutter/Android SDK installed, so an Android APK cannot be truthfully claimed as compiled here. To produce the installable APK, the project must be built on a machine with Flutter and Android SDK tooling, then `flutter build apk --release` can be run.

Before release: configure Supabase, run SQL scripts, deploy the AI server function, test RLS/roles, then build and sign the Android app.
