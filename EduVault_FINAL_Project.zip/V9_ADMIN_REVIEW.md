# EduVault V9 — Admin Review Dashboard

## New functionality
The admin can:
1. See all materials with `pending_review` status.
2. View file name, size, type and description.
3. Preview the uploaded PDF through a short-lived signed URL.
4. Enter review notes.
5. Approve, reject or remove a submission.

## Security
The dashboard checks the authenticated user's role, but production security must remain enforced by Supabase RLS/database policies.

## Database
Run `admin_review_schema.sql` after the earlier V7 database scripts if the review columns do not exist.

## Next stage
Student-facing published-material reader/download experience can now use the approved files while keeping the storage bucket private.
