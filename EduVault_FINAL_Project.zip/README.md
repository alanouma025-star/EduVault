# EduVault V2 — Authenticated Student Flow

This package combines the EduVault student prototype with a real Supabase authentication layer.

## Flow
Register/Login → Academic Profile → Subjects → Home → Materials → AI Tutor → Quiz → Progress

## Configuration
1. Run the EduVault backend `schema.sql` and `seed.sql` in Supabase SQL Editor.
2. Open `supabaseClient.js`.
3. Replace `YOUR_SUPABASE_URL` and `YOUR_SUPABASE_ANON_KEY`.
4. Serve the folder from a local web server rather than opening the HTML directly with `file://`.

## Security
Only use the public Supabase anon/publishable key in the browser. Never put a service-role key or private AI key in frontend code.

## Current demo content
The prototype includes Biology, Agriculture, Zoology, Botany, Soil Science, Chemistry, Education and Ecology, plus sample materials and quiz functionality.

Real downloadable educational documents must only be added when EduVault has the rights or permission to distribute them.
