# EduVault V4 — AI Tutor

## Student actions
The AI Tutor supports the planned modes:
- Explain
- Simplify
- Summarize
- Flashcards
- Test Me

## Security architecture

Student app
   ↓ authenticated request
Supabase Edge Function: ai-tutor
   ↓ private server-side API key
AI provider
   ↓
EduVault response

The AI provider key is never placed in the app.

## Material-aware tutoring
When a student opens an approved material and asks a question, the app can send the material ID. The Edge Function verifies that the material is published and uses its metadata as context.

A production version should additionally extract/index the authorized document text and retrieve relevant passages before sending context to the AI model.

## Activation
1. Deploy the Edge Function as `ai-tutor`.
2. Add `AI_API_KEY` to Supabase Edge Function secrets.
3. Connect the provider call inside the marked server-side section.
4. Keep all private credentials server-side.
