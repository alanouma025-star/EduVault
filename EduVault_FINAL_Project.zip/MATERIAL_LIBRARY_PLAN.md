# EduVault Material Library — V3

Student flow:

Subjects → Topics → Material list → Material details → Read → Download → Save → Report

## Material types
- Lecture notes
- Textbooks
- Revision notes
- Past papers
- Assignments
- Lab manuals
- Videos
- Other

## Important storage rule
Educational PDFs must not be uploaded unless EduVault has the legal right or permission to distribute them.

## Offline
The production Android app should download an approved PDF into device storage and keep a local record of the downloaded material. The current JavaScript module supplies the secure signed URL needed to fetch a private file.

## Next implementation
The next stage is the AI Tutor, connected to selected material context, followed by quizzes and progress analytics.
