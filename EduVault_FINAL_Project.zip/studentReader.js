import { supabase } from "./supabaseClient.js";
import { getSignedPdfUrl } from "./fileStorage.js";
export async function getPublishedMaterial(id){const {data,error}=await supabase.from("materials").select("*,subjects(name),topics(name),institutions(name),programmes(name)").eq("id",id).eq("status","approved").single();if(error)throw error;return data}
export async function openPublishedPdf(m){if(!m?.storage_path)throw new Error("No PDF is attached.");return getSignedPdfUrl(m.storage_path,3600)}
export async function saveMaterial(id){const {data:{user}}=await supabase.auth.getUser();if(!user)throw new Error("Please log in.");const {error}=await supabase.from("saved_materials").upsert({user_id:user.id,material_id:id},{onConflict:"user_id,material_id"});if(error)throw error}
export async function downloadPublishedPdf(m){const u=await openPublishedPdf(m);window.open(u,"_blank");return u}
