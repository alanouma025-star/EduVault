# EduVault Android Build

EduVault is a Flutter learning app with Home, Materials, Quiz, Profile, and a local Admin Dashboard.

## Build an APK using GitHub Actions on a phone
1. Upload this ZIP to the root of your EduVault GitHub repository. The workflow supports building from the uploaded ZIP or from extracted project files.
2. Open **Actions** in the repository.
3. Select **Build EduVault APK** and tap **Run workflow**.
4. Open the completed run and download the **EduVault-APK** artifact.
5. Extract the artifact ZIP and install `app-release.apk` on your Android phone. Allow installation from your browser/file manager if Android asks.

## Current functionality and limits
- Search and browse approved learning material records.
- Admin can select a PDF, copy it into app-private storage, add a title/subject/topic, and submit it as Pending Review.
- Admin can approve, return to pending, or delete materials. Approved records appear in the student Materials and Search screens.
- Material metadata is saved locally using SharedPreferences; selected PDFs are stored in the app's private documents folder.
- This is a single-device prototype. Admin is not protected by login, and records do not sync across devices. User management, quiz authoring, reports, analytics, and AI Tutor integration remain demo/placeholder screens. Do not publish it as a production service until authentication, a secure backend, cloud storage, and authorization are added.
- Only upload PDFs you own or are authorized to distribute.
