import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await _loadSavedMaterials();
  runApp(const EduVaultApp());
}

class EduVaultApp extends StatelessWidget {
  const EduVaultApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'EduVault', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
    home: const MainShell(),
  );
}

class MaterialItem {
  final String title, subject, topic, type;
  final String status;
  final String? filePath;
  const MaterialItem(this.title, this.subject, this.topic, this.type, {this.status='Approved', this.filePath});
  Map<String, dynamic> toJson() => {'title':title,'subject':subject,'topic':topic,'type':type,'status':status,'filePath':filePath};
  factory MaterialItem.fromJson(Map<String, dynamic> j) => MaterialItem(j['title'] ?? 'Untitled', j['subject'] ?? 'General', j['topic'] ?? 'General', j['type'] ?? 'Lecture Notes', status:j['status'] ?? 'Pending Review', filePath:j['filePath']);
}
final List<MaterialItem> materials = [
  MaterialItem('Introduction to Microscopy','Biology','Microscopy','Lecture Notes'),
  MaterialItem('Compound Microscope: Parts and Functions','Zoology','Microscopy','Lecture Notes'),
  MaterialItem('Soil Formation','Soil Science','Soil Formation','Lecture Notes'),
  MaterialItem('Types of Soil','Soil Science','Soil Classification','Study Notes'),
  MaterialItem('Introduction to Zoology','Zoology','Introduction','Lecture Notes'),
  MaterialItem('Photosynthesis','Botany','Plant Physiology','Lecture Notes'),
];
const _materialsKey = 'eduvault_materials_v1';
Future<void> _loadSavedMaterials() async {
  final prefs = await SharedPreferences.getInstance();
  final raw = prefs.getString(_materialsKey);
  if (raw == null) return;
  try { final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>(); materials..clear()..addAll(list.map(MaterialItem.fromJson)); } catch (_) {}
}
Future<void> _saveMaterials() async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString(_materialsKey, jsonEncode(materials.map((m)=>m.toJson()).toList()));
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState()=>_MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index=0;
  final pages=const [HomePage(),MaterialsPage(),QuizPage(),ProfilePage()];
  @override Widget build(BuildContext context)=>Scaffold(
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),
      destinations:const [
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'Materials'),
        NavigationDestination(icon:Icon(Icons.quiz_outlined),selectedIcon:Icon(Icons.quiz),label:'Quiz'),
        NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),
      ],
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('EduVault',style:TextStyle(fontSize:30,fontWeight:FontWeight.bold)),
    const Text('Learn. Practice. Succeed.',style:TextStyle(fontSize:16)),
    const SizedBox(height:20),
    TextField(
      decoration:InputDecoration(hintText:'Search notes, topics, subjects...',prefixIcon:const Icon(Icons.search),border:OutlineInputBorder(borderRadius:BorderRadius.circular(16))),
      onSubmitted:(q)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SearchPage(query:q))),
    ),
    const SizedBox(height:22),
    const Text('Your study area',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    const SizedBox(height:10),
    Wrap(spacing:8,runSpacing:8,children:[
      for(final s in ['Biology','Zoology','Botany','Agriculture','Soil Science'])
        ActionChip(label:Text(s),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SearchPage(query:s)))),
    ]),
    const SizedBox(height:25),
    Card(child:ListTile(leading:const Icon(Icons.auto_awesome),title:const Text('AI Tutor'),subtitle:const Text('Ask questions and get help with your studies.'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AiTutorPage())))),
    Card(child:ListTile(leading:const Icon(Icons.trending_up),title:const Text('Progress'),subtitle:const Text('Quiz average: 82%  •  6 topics studied'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProgressPage())))),
  ]));
}

class MaterialsPage extends StatefulWidget {
  const MaterialsPage({super.key});
  @override State<MaterialsPage> createState()=>_MaterialsPageState();
}
class _MaterialsPageState extends State<MaterialsPage>{
  String q='';
  @override Widget build(BuildContext context){
    final list=materials.where((m)=>m.status=='Approved' && (q.isEmpty||'${m.title} ${m.subject} ${m.topic}'.toLowerCase().contains(q.toLowerCase()))).toList();
    return SafeArea(child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(16,16,16,8),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search materials',border:OutlineInputBorder()),onChanged:(v)=>setState(()=>q=v))),
      Expanded(child:ListView.builder(itemCount:list.length,itemBuilder:(_,i)=>Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),child:ListTile(
        leading:const CircleAvatar(child:Icon(Icons.picture_as_pdf)),title:Text(list[i].title),subtitle:Text('${list[i].subject} • ${list[i].topic}'),trailing:const Icon(Icons.chevron_right),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReaderPage(item:list[i]))),
      )))),
    ]));
  }
}

class SearchPage extends StatelessWidget{
  final String query; const SearchPage({super.key,required this.query});
  @override Widget build(BuildContext context){
    final list=materials.where((m)=>m.status=='Approved' && '${m.title} ${m.subject} ${m.topic}'.toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(appBar:AppBar(title:Text('Results for "$query"')),body:list.isEmpty?const Center(child:Text('No matching materials yet.')):ListView(children:[
      for(final m in list) ListTile(leading:const Icon(Icons.picture_as_pdf),title:Text(m.title),subtitle:Text('${m.subject} • ${m.topic}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReaderPage(item:m))))
    ]));
  }
}

class ReaderPage extends StatelessWidget{
  final MaterialItem item; const ReaderPage({super.key,required this.item});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Material')),body:ListView(padding:const EdgeInsets.all(18),children:[
    Text(item.title,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    Text('${item.subject} • ${item.topic} • ${item.type}'),const SizedBox(height:20),
    const Text('Study material',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),
    if(item.filePath != null) FilledButton.icon(onPressed:() async { final f=File(item.filePath!); if(await f.exists()) { await OpenFilex.open(f.path); } else if(context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('The saved PDF could not be found.'))); } }, icon:const Icon(Icons.picture_as_pdf), label:const Text('OPEN PDF FILE')),
    if(item.filePath == null) const Text('This sample item has no PDF attached yet.'),
    const Text('This is the EduVault reader preview. In the connected version, approved PDF materials will open here and can be downloaded for offline study.'),
    const SizedBox(height:25),
    FilledButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Saved to your study list.'))),icon:const Icon(Icons.bookmark_add),label:const Text('SAVE')),
    OutlinedButton.icon(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Offline download will be available when storage is connected.'))),icon:const Icon(Icons.download),label:const Text('DOWNLOAD FOR OFFLINE')),
    FilledButton.icon(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AiTutorPage())),icon:const Icon(Icons.auto_awesome),label:const Text('ASK AI TUTOR')),
  ]));
}

class AiTutorPage extends StatefulWidget{
  const AiTutorPage({super.key}); @override State<AiTutorPage> createState()=>_AiTutorPageState();
}
class _AiTutorPageState extends State<AiTutorPage>{
  final c=TextEditingController(); String answer='Ask me a question about Biology, Agriculture, Zoology, Botany or Soil Science.';
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('AI Tutor')),body:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
    Expanded(child:SingleChildScrollView(child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(answer))))),
    TextField(controller:c,decoration:const InputDecoration(hintText:'Type your question...',border:OutlineInputBorder())),
    const SizedBox(height:8),
    FilledButton(onPressed:()=>setState((){
      final q=c.text.trim(); answer=q.isEmpty?'Please type a question.':'Demo tutor response: I can explain "$q" step by step. The connected EduVault version will use the AI service and approved study materials.'; c.clear();
    }),child:const Text('ASK')),
  ])));
}

class QuizPage extends StatefulWidget{
  const QuizPage({super.key}); @override State<QuizPage> createState()=>_QuizPageState();
}
class _QuizPageState extends State<QuizPage>{
  int score=0,answered=0;
  void answer(bool correct)=>setState(()=>{if(correct)score++;answered++;});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[
    const Text('Microscopy Quiz',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),const SizedBox(height:12),
    const Text('What is the main function of the objective lens?'),const SizedBox(height:8),
    for(final x in ['To magnify the specimen','To illuminate the room','To hold the microscope'])
      ListTile(title:Text(x),leading:const Icon(Icons.radio_button_unchecked),onTap:()=>answer(x=='To magnify the specimen')),
    const Divider(),Text('Score: $score/$answered'),
    if(answered>0)Text(score==answered?'Correct! 🎉':'Review the topic and try again.'),
  ]));
}

class ProgressPage extends StatelessWidget{
  const ProgressPage({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('My Progress')),body:ListView(padding:const EdgeInsets.all(18),children:const[
    ListTile(leading:Icon(Icons.percent),title:Text('Overall progress'),trailing:Text('68%')),
    ListTile(leading:Icon(Icons.quiz),title:Text('Average quiz score'),trailing:Text('82%')),
    ListTile(leading:Icon(Icons.menu_book),title:Text('Topics studied'),trailing:Text('6')),
    ListTile(leading:Icon(Icons.local_fire_department),title:Text('Study streak'),trailing:Text('4 days')),
  ]));
}

class ProfilePage extends StatelessWidget{
  const ProfilePage({super.key});
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(18),children:[
    const CircleAvatar(radius:42,child:Icon(Icons.person,size:45)),const SizedBox(height:12),
    const Center(child:Text('Student',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))),
    const Center(child:Text('Kenya • University • Education - Agriculture & Biology')),
    const SizedBox(height:20),
    const Card(child:ListTile(leading:Icon(Icons.school),title:Text('Academic Profile'),subtitle:Text('University of Eldoret'))),
    const Card(child:ListTile(leading:Icon(Icons.download),title:Text('Offline Materials'),subtitle:Text('Your downloaded study materials'))),
    const Card(child:ListTile(leading:Icon(Icons.emoji_events),title:Text('Achievements'),subtitle:Text('First Quiz • 90% Quiz Score'))),
    const SizedBox(height:18),
    Card(child:ListTile(leading:const Icon(Icons.admin_panel_settings),title:const Text('Admin Dashboard'),subtitle:const Text('Manage learning materials and content'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AdminDashboard())))),
  ]));
}

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int selected = 0;
  final subjects = <String>['Biology','Zoology','Botany','Agriculture','Soil Science'];
  final users = <Map<String,String>>[
    {'name':'Demo Student','role':'Student','status':'Active'},
    {'name':'Demo Contributor','role':'Contributor','status':'Active'},
  ];
  void refresh() => setState(() {});
  @override Widget build(BuildContext context) {
    final pages = [_home(), _materialsPage(), _usersPage(), _subjectsPage(), _quizzesPage(), _reportsPage(), _analyticsPage(), _settingsPage()];
    return Scaffold(
      appBar: AppBar(title: const Text('EduVault Admin'), actions:[
        IconButton(onPressed:refresh, icon:const Icon(Icons.refresh)),
        IconButton(onPressed:()=>_message('Local demo administrator. Add real authentication before publishing.'), icon:const Icon(Icons.account_circle)),
      ]),
      drawer: Drawer(child: SafeArea(child: ListView(children:[
        const DrawerHeader(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.admin_panel_settings,size:46),SizedBox(height:10),Text('EduVault',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),Text('Administrator Dashboard')])),
        _nav(Icons.dashboard,'Dashboard',0),_nav(Icons.library_books,'Materials',1),_nav(Icons.people,'Users',2),_nav(Icons.category,'Subjects & Topics',3),_nav(Icons.quiz,'Quizzes',4),_nav(Icons.flag,'Reports',5),_nav(Icons.analytics,'Analytics',6),_nav(Icons.settings,'Settings',7),
      ]))),
      body: pages[selected],
      floatingActionButton: (selected==1||selected==3||selected==4) ? FloatingActionButton.extended(onPressed:selected==1?_addMaterial:selected==3?_addSubject:_addQuiz,icon:const Icon(Icons.add),label:Text(selected==1?'Upload PDF / add material':selected==3?'Add subject':'Create quiz')) : null,
    );
  }
  Widget _nav(IconData icon,String label,int i)=>ListTile(leading:Icon(icon),title:Text(label),selected:selected==i,onTap:(){setState(()=>selected=i);Navigator.pop(context);});
  Widget _home()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Admin Dashboard',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const Text('Manage EduVault learning content on this device.'),const SizedBox(height:18),
    Wrap(spacing:10,runSpacing:10,children:[_stat('Materials','${materials.length}',Icons.library_books),_stat('Approved','${materials.where((m)=>m.status=='Approved').length}',Icons.check_circle),_stat('Pending','${materials.where((m)=>m.status=='Pending Review').length}',Icons.pending_actions),_stat('Subjects','${subjects.length}',Icons.category),_stat('Users','${users.length}',Icons.people)]),
    const SizedBox(height:22),const Text('Quick actions',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    _quick('Upload / add lecture material',Icons.upload_file,1),_quick('Review pending materials',Icons.fact_check,1),_quick('Manage users',Icons.manage_accounts,2),_quick('Manage subjects and topics',Icons.category,3),_quick('Create a quiz',Icons.add_task,4),
    const SizedBox(height:12),const Text('Important: this dashboard currently stores material records and PDF files locally on this device. It is not a secure online multi-user admin system.'),
  ]);
  Widget _stat(String title,String value,IconData icon)=>SizedBox(width:145,child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,size:28),const SizedBox(height:8),Text(value,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(title)]))));
  Widget _quick(String title,IconData icon,int page)=>Card(child:ListTile(leading:Icon(icon),title:Text(title),trailing:const Icon(Icons.chevron_right),onTap:()=>setState(()=>selected=page)));
  Widget _materialsPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Materials Management',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const Text('PDFs added here are stored in this app on this device.'),const SizedBox(height:12),
    if(materials.isEmpty) const Text('No materials yet.'),
    ...materials.map((m)=>Card(child:ListTile(leading:Icon(m.filePath==null?Icons.menu_book:Icons.picture_as_pdf),title:Text(m.title),subtitle:Text('${m.subject} • ${m.status}${m.filePath==null?' • Demo item':' • PDF attached'}'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(v)async{if(v=='approve'){final i=materials.indexOf(m);materials[i]=MaterialItem(m.title,m.subject,m.topic,m.type,status:'Approved',filePath:m.filePath);await _saveMaterials();refresh();}else if(v=='pending'){final i=materials.indexOf(m);materials[i]=MaterialItem(m.title,m.subject,m.topic,m.type,status:'Pending Review',filePath:m.filePath);await _saveMaterials();refresh();}else if(v=='delete'){materials.remove(m);await _saveMaterials();refresh();}},itemBuilder:(_)=>const[PopupMenuItem(value:'approve',child:Text('Approve & publish')),PopupMenuItem(value:'pending',child:Text('Mark pending')),PopupMenuItem(value:'delete',child:Text('Delete'))])))),
  ]);
  Widget _usersPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('User Management',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    const Text('Demo user records only. Real accounts require authentication and a backend.'),
    ...users.map((u)=>Card(child:ListTile(
      leading:CircleAvatar(child:Text(u['name']![0])), title:Text(u['name']!),
      subtitle:Text('${u['role']} • ${u['status']}'),
      trailing:PopupMenuButton<String>(onSelected:(v)=>setState(()=>u['status']=v=='suspend'?'Suspended':'Active'),itemBuilder:(_)=>const[
        PopupMenuItem(value:'suspend',child:Text('Suspend')),
        PopupMenuItem(value:'restore',child:Text('Restore')),
      ]),
    ))),
  ]);
  Widget _subjectsPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Subjects & Topics',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    ...subjects.map((s)=>Card(child:ListTile(leading:const Icon(Icons.book),title:Text(s),subtitle:const Text('Subject available for material categorization'),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){setState(()=>subjects.remove(s));})))),
  ]);
  Widget _quizzesPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Quiz Management',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    const Card(child:ListTile(leading:Icon(Icons.quiz),title:Text('Microscopy Quiz'),subtitle:Text('10 questions • Published'))),
    const Card(child:ListTile(leading:Icon(Icons.quiz),title:Text('Introduction to Zoology'),subtitle:Text('15 questions • Draft'))),
    const Card(child:ListTile(leading:Icon(Icons.quiz),title:Text('Soil Science Basics'),subtitle:Text('20 questions • Published'))),
    const Text('Quiz creation and online result storage are not connected yet.'),
  ]);
  Widget _reportsPage()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Reports & Moderation',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const Card(child:ListTile(leading:Icon(Icons.flag),title:Text('Reported material'),subtitle:Text('No live reports — demo screen'))),const Card(child:ListTile(leading:Icon(Icons.person_off),title:Text('Reported user'),subtitle:Text('No live reports — demo screen')))]);
  Widget _analyticsPage()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Analytics',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),_metric('Materials on this device','${materials.length}'),_metric('Approved materials','${materials.where((m)=>m.status=='Approved').length}'),_metric('PDF files attached','${materials.where((m)=>m.filePath!=null).length}'),_metric('Users','${users.length}'),const Text('Usage and download statistics require a connected backend.')]);
  Widget _metric(String a,String b)=>Card(child:ListTile(title:Text(a),trailing:Text(b,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))));
  Widget _settingsPage()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Settings',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const Card(child:ListTile(leading:Icon(Icons.security),title:Text('Admin security'),subtitle:Text('Demo only — add authentication before public release'))),const Card(child:ListTile(leading:Icon(Icons.storage),title:Text('Storage'),subtitle:Text('PDFs and material records are stored locally'))),const Card(child:ListTile(leading:Icon(Icons.smart_toy),title:Text('AI Tutor'),subtitle:Text('Demo responses; server-side AI is not connected'))),const Card(child:ListTile(leading:Icon(Icons.policy),title:Text('Content policy'),subtitle:Text('Publish only authorized, open-license or rights-granted material')))]);
  Future<void> _addMaterial() async {
    final title=TextEditingController(), subject=TextEditingController(text:'Zoology'), topic=TextEditingController(text:'General');
    String? selectedPath;
    final result=await showDialog<bool>(context:context,builder:(dialogContext)=>StatefulBuilder(builder:(context,setDialogState)=>AlertDialog(title:const Text('Add learning material'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Material title')),TextField(controller:subject,decoration:const InputDecoration(labelText:'Subject')),TextField(controller:topic,decoration:const InputDecoration(labelText:'Topic')),const SizedBox(height:12),OutlinedButton.icon(onPressed:()async{final picked=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['pdf'],withData:true);if(picked!=null){final file=picked.files.single;try{final dir=await getApplicationDocumentsDirectory();final pdfDir=Directory('${dir.path}/eduvault_pdfs');if(!await pdfDir.exists())await pdfDir.create(recursive:true);final safeName='${DateTime.now().millisecondsSinceEpoch}_${file.name.replaceAll(RegExp(r'[^a-zA-Z0-9._-]'),'_')}';final out=File('${pdfDir.path}/$safeName');if(file.bytes!=null){await out.writeAsBytes(file.bytes!);}else if(file.path!=null){await File(file.path!).copy(out.path);}selectedPath=out.path;setDialogState((){});}catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not save PDF: $e')));}},icon:const Icon(Icons.upload_file),label:Text(selectedPath==null?'Choose PDF file':'PDF attached'))])),actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(dialogContext,true),child:const Text('Add material'))])));
    if(result==true && title.text.trim().isNotEmpty){materials.add(MaterialItem(title.text.trim(),subject.text.trim().isEmpty?'General':subject.text.trim(),topic.text.trim().isEmpty?'General':topic.text.trim(),'Lecture Notes',status:'Pending Review',filePath:selectedPath));await _saveMaterials();refresh();}
  }
  Future<void> _addSubject() async {final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(d)=>AlertDialog(title:const Text('Add subject'),content:TextField(controller:c,decoration:const InputDecoration(labelText:'Subject name')),actions:[TextButton(onPressed:()=>Navigator.pop(d,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(d,true),child:const Text('Add'))]));if(ok==true&&c.text.trim().isNotEmpty)setState(()=>subjects.add(c.text.trim()));}
  void _addQuiz()=>_message('Quiz builder is a placeholder. Quiz creation needs its own question editor and storage.');
  void _message(String text)=>showDialog(context:context,builder:(_)=>AlertDialog(content:Text(text),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))]));
}
