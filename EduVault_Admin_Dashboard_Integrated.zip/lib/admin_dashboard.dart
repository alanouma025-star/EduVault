import 'package:flutter/material.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});
  @override State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int index = 0;
  final materials = <Map<String,String>>[
    {'title':'Introduction to Zoology','subject':'Zoology','status':'Approved'},
    {'title':'Microscopy','subject':'Zoology','status':'Pending Review'},
    {'title':'Introduction to Soil Science','subject':'Soil Science','status':'Approved'},
  ];
  final users = <Map<String,String>>[
    {'name':'Demo Student','role':'Student','status':'Active'},
    {'name':'Demo Contributor','role':'Contributor','status':'Active'},
  ];

  @override Widget build(BuildContext context) {
    final pages = [_dashboard(),_materials(),_users(),_quizzes(),_reports(),_settings()];
    return Scaffold(
      appBar: AppBar(title: const Text('EduVault Admin')),
      drawer: Drawer(child: SafeArea(child: ListView(children:[
        const DrawerHeader(child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Icon(Icons.admin_panel_settings,size:44), SizedBox(height:8),
          Text('EduVault',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
          Text('Administrator')
        ])),
        _nav(Icons.dashboard,'Dashboard',0),_nav(Icons.library_books,'Materials',1),
        _nav(Icons.people,'Users',2),_nav(Icons.quiz,'Quizzes',3),
        _nav(Icons.flag,'Reports',4),_nav(Icons.settings,'Settings',5),
      ]))),
      body: pages[index],
      floatingActionButton: index==1 ? FloatingActionButton.extended(
        onPressed:_addMaterial,icon:const Icon(Icons.add),label:const Text('Add material')) : null,
    );
  }

  Widget _nav(IconData icon,String title,int i)=>ListTile(
    leading:Icon(icon),title:Text(title),selected:index==i,
    onTap:(){setState(()=>index=i);Navigator.pop(context);}
  );

  Widget _dashboard()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Admin Dashboard',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),const Text('Manage EduVault from one place.'),
    const SizedBox(height:20),
    _stat('Users','${users.length}',Icons.people),_stat('Materials','${materials.length}',Icons.library_books),
    _stat('Pending review','${materials.where((m)=>m['status']=='Pending Review').length}',Icons.pending_actions),
    _stat('Quizzes','4',Icons.quiz),
    const SizedBox(height:20),const Text('Quick Actions',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
    _action('Upload / add lecture notes',Icons.upload_file,()=>setState(()=>index=1)),
    _action('Manage users',Icons.manage_accounts,()=>setState(()=>index=2)),
    _action('Manage quizzes',Icons.add_task,()=>setState(()=>index=3)),
    _action('Review reports',Icons.flag,()=>setState(()=>index=4)),
  ]);

  Widget _stat(String t,String v,IconData i)=>Card(child:ListTile(
    leading:Icon(i,size:34),title:Text(t),trailing:Text(v,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))));

  Widget _action(String t,IconData i,VoidCallback f)=>Card(child:ListTile(
    leading:Icon(i),title:Text(t),trailing:const Icon(Icons.chevron_right),onTap:f));

  Widget _materials()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Materials',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    ...materials.map((m)=>Card(child:ListTile(
      leading:const Icon(Icons.picture_as_pdf),title:Text(m['title']!),
      subtitle:Text('${m['subject']} • ${m['status']}'),
      trailing:PopupMenuButton<String>(
        onSelected:(v){setState((){
          if(v=='approve')m['status']='Approved';
          if(v=='reject')m['status']='Rejected';
          if(v=='delete')materials.remove(m);
        });},
        itemBuilder:(_)=>const[
          PopupMenuItem(value:'approve',child:Text('Approve')),
          PopupMenuItem(value:'reject',child:Text('Reject')),
          PopupMenuItem(value:'delete',child:Text('Delete')),
        ])))
  ]);

  Widget _users()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Users',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    ...users.map((u)=>Card(child:ListTile(
      leading:CircleAvatar(child:Text(u['name']![0])),title:Text(u['name']!),
      subtitle:Text('${u['role']} • ${u['status']}'),
      trailing:PopupMenuButton<String>(
        onSelected:(v)=>setState(()=>u['status']=v=='suspend'?'Suspended':'Active'),
        itemBuilder:(_)=>const[
          PopupMenuItem(value:'suspend',child:Text('Suspend')),
          PopupMenuItem(value:'restore',child:Text('Restore')),
        ])))
  ]);

  Widget _quizzes()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Quizzes',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    _quiz('Microscopy Quiz','10 questions','Published'),
    _quiz('Introduction to Zoology','15 questions','Draft'),
    _quiz('Soil Science Basics','20 questions','Published'),
    const SizedBox(height:12),
    FilledButton.icon(onPressed:()=>_info('Quiz builder will be connected to the database in the next backend step.'),
      icon:const Icon(Icons.add),label:const Text('Create new quiz')),
  ]);

  Widget _quiz(String t,String s,String st)=>Card(child:ListTile(
    leading:const Icon(Icons.quiz),title:Text(t),subtitle:Text('$s • $st')));

  Widget _reports()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Reports & Moderation',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    Card(child:ListTile(leading:const Icon(Icons.flag),title:const Text('Reported material'),
      subtitle:const Text('Pending review • 1 report'),
      trailing:FilledButton(onPressed:()=>_info('Report review opened.'),child:const Text('Review')))),
  ]);

  Widget _settings()=>ListView(padding:const EdgeInsets.all(16),children:[
    const Text('Settings',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    const Card(child:ListTile(leading:Icon(Icons.security),title:Text('Admin security'),subtitle:Text('Role-based access'))),
    const Card(child:ListTile(leading:Icon(Icons.storage),title:Text('Storage'),subtitle:Text('Learning materials and PDFs'))),
    const Card(child:ListTile(leading:Icon(Icons.smart_toy),title:Text('AI Tutor'),subtitle:Text('Server-side AI connection'))),
  ]);

  void _addMaterial(){
    final title=TextEditingController(),subject=TextEditingController(text:'Zoology');
    showDialog(context:context,builder:(_)=>AlertDialog(
      title:const Text('Add learning material'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:title,decoration:const InputDecoration(labelText:'Material title')),
        TextField(controller:subject,decoration:const InputDecoration(labelText:'Subject')),
        const SizedBox(height:8),const Text('Demo mode: real PDF upload will be connected to secure storage later.')
      ]),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
        FilledButton(onPressed:(){
          if(title.text.trim().isNotEmpty)setState(()=>materials.add({'title':title.text.trim(),'subject':subject.text.trim(),'status':'Pending Review'}));
          Navigator.pop(context);
        },child:const Text('Add'))
      ]));
  }

  void _info(String s)=>showDialog(context:context,builder:(_)=>AlertDialog(
    content:Text(s),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))]));
}
